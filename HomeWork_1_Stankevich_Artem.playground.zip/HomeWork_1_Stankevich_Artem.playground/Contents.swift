import Foundation

/* Задание 1
Написать основные отличия между объектами в ООП
Отличия:
1 reference type / value type - при обращении могут передавать ссылку или копировать данные
2 иметь наследование / не иметь наследование - могут вызывать часть своего поведения из другого
3 сохраняться в stek / hip - более быстрое / менее быстрое выполнение
*/
 
// Задание 2
// Придумать пример полиморфизма и реализовать его

class Creature {
    var name: String
    init (name: String) {
        self.name = name
    }
    func saySomething () -> String {
        return "Голос"
    }
}
class Human : Creature {
    let clas: String
    init (name: String, clas: String) {
        self.clas = clas
        super.init (name: name)
    }
    override func saySomething() -> String {
    return "Привет"
}
}
class Cat : Creature {
    let clas: String
    init (name: String, clas: String) {
        self.clas = clas
        super.init (name: name)
}
        override func saySomething() -> String {
        return "Мяу"
    }
}
class Dog : Creature {
    let clas: String
    init (name: String, clas: String) {
        self.clas = clas
        super.init (name: name)
    }
    override func saySomething() -> String {
    return "Гав"
}
}
let doctor = Human(name: "Evgenii", clas: "Human").saySomething()
let dog = Dog(name: "Тузик", clas: "Dog").saySomething()
let cat = Cat(name: "Мурзик", clas: "Cat").saySomething()



// Задание 3
// Создать очередь выполнения используя замыкания

/// Печать N цифр с интервалом 1 сек.
func printNumberTimes (_ number: Int) {
    guard number != 0 else {
        print("Не заполнено количество")
        return
    }
    var printArray = [()->()]()
    for i in 1...number {
        let printClosure : () -> () = {() in
            print(i)
            sleep(1)
        }
        printArray.append(printClosure)
    }
    for closure in printArray {
        closure()
    }
}
printNumberTimes (5)

